const validacaracter = require("./validacaracter")
const validaInfo = require("./validaInfo")
const validaSaleDate =require("./validaSaleDate")

module.exports = { validacaracter, validaInfo, validaSaleDate };